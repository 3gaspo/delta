const guestParameter = 'guest';
const guestFlag = 'app-ui:guest';
const guestDataPrefix = `${guestFlag}:`;

function initializeGuestSession() {
  if (typeof window === 'undefined') return { active: false };

  const url = new URL(window.location.href);
  const requested = url.searchParams.get(guestParameter) === '1';
  let storage: Storage | undefined;
  let active = requested;
  try {
    const session = window.sessionStorage;
    if (requested) session.setItem(guestFlag, '1');
    active = requested || session.getItem(guestFlag) === '1';
    storage = session;
  } catch {
    // Guest data can still stay in memory when browser storage is unavailable.
  }
  if (requested) {
    url.searchParams.delete(guestParameter);
    window.history.replaceState(window.history.state, '', url);
  }
  return { active, storage };
}

// Pick the mode before any app can initialize its Firebase providers.
const guestSession = initializeGuestSession();
let guestStorage = guestSession.storage;
const guestMemory = new Map<string, string>();
export const isGuestSession = guestSession.active;
export const guestUser = { uid: 'guest-session', email: '' } as const;

export const appStorage = {
  getItem(key: string): string | null {
    if (!isGuestSession) return localStorage.getItem(key);
    return guestStorage ? guestStorage.getItem(guestDataPrefix + key) : guestMemory.get(key) ?? null;
  },
  setItem(key: string, value: string) {
    if (!isGuestSession) localStorage.setItem(key, value);
    else if (guestStorage) guestStorage.setItem(guestDataPrefix + key, value);
    else guestMemory.set(key, value);
  },
  removeItem(key: string) {
    if (!isGuestSession) localStorage.removeItem(key);
    else if (guestStorage) guestStorage.removeItem(guestDataPrefix + key);
    else guestMemory.delete(key);
  },
  keys(): string[] {
    if (!isGuestSession) return Object.keys(localStorage);
    if (!guestStorage) return [...guestMemory.keys()];
    return Object.keys(guestStorage)
      .filter(key => key.startsWith(guestDataPrefix))
      .map(key => key.slice(guestDataPrefix.length));
  },
};

export function startGuestSession() {
  const url = new URL(window.location.href);
  url.searchParams.set(guestParameter, '1');
  window.location.replace(url);
}

export function endGuestSession() {
  if (!isGuestSession) return;
  for (const key of appStorage.keys()) appStorage.removeItem(key);
  guestStorage?.removeItem(guestFlag);
  guestStorage = undefined;
  window.location.reload();
}
