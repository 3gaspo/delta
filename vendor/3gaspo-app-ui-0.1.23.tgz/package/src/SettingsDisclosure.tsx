import type { ReactNode } from 'react';
import { ChevronDown } from 'lucide-react';

interface SettingsDisclosureProps {
  label: string;
  children: ReactNode;
  id?: string;
  className?: string;
}

export function SettingsDisclosure({ label, children, id, className = '' }: SettingsDisclosureProps) {
  return (
    <details id={id} className={`ui-settings-disclosure ${className}`}>
      <summary className="ui-settings-disclosure-summary">
        <span className="ui-section-title">{label}</span>
        <ChevronDown size={18} aria-hidden="true" />
      </summary>
      <div className="ui-settings-disclosure-content">{children}</div>
    </details>
  );
}
