import { useState } from 'react';
import { ActionButton } from './ActionButton';
import { Dialog, DialogActions } from './Dialog';
import { endGuestSession } from './guestSession';

export function GuestAccount() {
  const [confirm, setConfirm] = useState(false);
  const close = () => setConfirm(false);

  return <section className="ui-section-card ui-auth-fields" aria-label="Guest session">
    <h2 className="ui-section-title">Guest session</h2>
    <p className="ui-auth-note">Your changes stay in this tab for this session.</p>
    <button type="button" className="ui-button ui-button-secondary" onClick={() => setConfirm(true)}>End guest session</button>
    <Dialog open={confirm} onClose={close} title="End guest session?">
      <p className="ui-confirm-description">This clears the data you entered during this guest session.</p>
      <DialogActions>
        <button type="button" className="ui-button ui-button-secondary" onClick={close}>Cancel</button>
        <ActionButton className="ui-button ui-button-danger" onClick={endGuestSession}>End session</ActionButton>
      </DialogActions>
    </Dialog>
  </section>;
}
