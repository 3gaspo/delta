import { useId, useLayoutEffect, useRef, useState } from 'react';
import { Eye, EyeOff, Lock, Mail } from 'lucide-react';
import { ValidatedForm } from './ValidatedForm';
import { startGuestSession } from './guestSession';

type Props = {
  onAuthenticate: (email: string, password: string, signUp: boolean) => Promise<unknown>;
  onResetPassword?: (email: string) => Promise<void>;
  allowUsername?: boolean;
};

const actions = {
  signIn: { submit: 'Sign in', busy: 'Signing in…' },
  signUp: { submit: 'Create account', busy: 'Creating account…' },
  reset: { submit: 'Send reset link', busy: 'Sending reset link…' },
};

function resetErrorMessage(failure: unknown) {
  const code = failure && typeof failure === 'object' && 'code' in failure ? failure.code : null;
  switch (code) {
    case 'auth/user-not-found': return 'No account was found for this email address.';
    case 'auth/invalid-email': return 'Enter a valid email address.';
    case 'auth/too-many-requests': return 'Too many requests. Try again later.';
    default: return 'Could not send the reset link. Try again.';
  }
}

export function AuthForm({ onAuthenticate, onResetPassword, allowUsername = false }: Props) {
  const id = useId();
  const emailInput = useRef<HTMLInputElement>(null);
  const focusEmail = useRef(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [mode, setMode] = useState<keyof typeof actions>('signIn');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [sent, setSent] = useState(false);
  const resetting = mode === 'reset';
  const signUp = mode === 'signUp';
  const acceptUsername = allowUsername && !resetting;
  const action = actions[mode];

  useLayoutEffect(() => {
    if (focusEmail.current) {
      emailInput.current?.focus();
      focusEmail.current = false;
    }
  }, [resetting]);

  function changeMode(nextMode: keyof typeof actions) {
    focusEmail.current = resetting || nextMode === 'reset';
    setMode(nextMode);
    setError('');
    setSent(false);
  }

  async function submit() {
    setBusy(true);
    setError('');
    setSent(false);
    try {
      if (resetting && onResetPassword) {
        await onResetPassword(email.trim());
        setSent(true);
      } else {
        await onAuthenticate(email.trim(), password, signUp);
      }
    } catch (failure) {
      setError(resetting ? resetErrorMessage(failure) : failure instanceof Error ? failure.message : 'Could not sign in. Try again.');
    } finally {
      setBusy(false);
    }
  }

  return <div className="ui-auth-fields">
    {resetting ? <h2 className="ui-item-title">Reset your password</h2> : (
      <div className="ui-segments" role="group" aria-label="Account access">
        <button type="button" className="ui-option" aria-pressed={!signUp} disabled={busy} onClick={() => changeMode('signIn')}>Sign in</button>
        <button type="button" className="ui-option" aria-pressed={signUp} disabled={busy} onClick={() => changeMode('signUp')}>Create account</button>
      </div>
    )}
    <ValidatedForm key={resetting ? 'reset' : 'account'} className="ui-auth-fields" busyLabel={action.busy} onSubmit={submit}>
      <div className="ui-auth-field">
        <label className="ui-field-label" htmlFor={id + '-email'}>{acceptUsername ? 'Email or username' : 'Email address'}</label>
        <div className="ui-auth-input">
          <Mail aria-hidden="true" size={20} />
          <input ref={emailInput} id={id + '-email'} name="email" type={acceptUsername ? 'text' : 'email'} autoComplete={resetting ? 'email' : 'username'} autoCapitalize="none" spellCheck={false} required readOnly={busy} value={email} onChange={event => {
            setEmail(event.target.value);
            if (resetting) { setError(''); setSent(false); }
          }} className="ui-field ui-field-leading" />
        </div>
      </div>
      {!resetting && (
        <div className="ui-auth-field">
          <label className="ui-field-label" htmlFor={id + '-password'}>Password</label>
          <div className="ui-auth-input">
            <Lock aria-hidden="true" size={20} />
            <input id={id + '-password'} name="password" type={show ? 'text' : 'password'} autoComplete={signUp ? 'new-password' : 'current-password'} required readOnly={busy} value={password} onChange={event => setPassword(event.target.value)} className="ui-field ui-field-leading ui-field-trailing" />
            <button type="button" className="ui-auth-password" aria-label={show ? 'Hide password' : 'Show password'} aria-pressed={show} onClick={() => setShow(previous => !previous)}>{show ? <EyeOff size={20} /> : <Eye size={20} />}</button>
          </div>
        </div>
      )}
      {error && <p className="ui-error" role="alert">{error}</p>}
      {sent && <p className="ui-auth-note" role="status">If an account exists for this email address, you’ll receive a password reset link.</p>}
      <button className="ui-button ui-button-primary ui-auth-submit" type="submit" disabled={busy}>{action.submit}</button>
    </ValidatedForm>
    <div className="ui-auth-actions">
      {resetting ? (
        <button type="button" className="ui-button ui-auth-link" disabled={busy} onClick={() => changeMode('signIn')}>Back to sign in</button>
      ) : (
        <>
          {onResetPassword && !signUp && <button type="button" className="ui-button ui-auth-link" disabled={busy} onClick={() => changeMode('reset')}>Forgot password?</button>}
          <button type="button" className="ui-button ui-button-secondary" disabled={busy} onClick={startGuestSession}>Continue as guest</button>
          <p className="ui-auth-note">Guest changes stay in this tab for this session.</p>
        </>
      )}
    </div>
  </div>;
}
