import { createContext, useContext, useEffect, useId, useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { BookOpen, ChevronDown, ChevronRight, ListChecks, type LucideIcon } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { Dialog, DialogActions } from './Dialog';

interface TutorialIntro {
  logo: string;
  title: string;
  description: string;
}

interface TutorialAction {
  icon: LucideIcon;
  text: string;
  primary?: boolean;
}

interface TutorialTab {
  icon: LucideIcon;
  title: string;
  actions: readonly [TutorialAction, ...TutorialAction[]];
  legend?: readonly { color: string; text: string }[];
}

export type TutorialPages = readonly [TutorialIntro, TutorialTab, ...TutorialTab[]];

export interface FeatureSection {
  title: string;
  entries: readonly { title: string; text: string; formula?: string }[];
}

interface TutorialProviderProps {
  appName: string;
  accountId: string | null;
  homePath?: string;
  ready?: boolean;
  pages: TutorialPages;
  children: ReactNode;
}

const TutorialContext = createContext<{ buttonId: string; open: () => void } | null>(null);

export function TutorialProvider({ appName, accountId, homePath = '/home', ready = true, pages, children }: TutorialProviderProps) {
  const { pathname } = useLocation();
  const buttonId = useId();
  const storageKey = accountId ? `app-ui:tutorial:${appName}:${accountId}` : null;
  const [session, setSession] = useState<{ key: string; openedFrom: 'home' | 'settings' | null } | null>(null);
  const openedFrom = session?.key === storageKey ? session.openedFrom : null;

  useEffect(() => {
    if (!ready || !storageKey || pathname !== homePath || session?.key === storageKey) return;

    let seen = false;
    try {
      seen = window.localStorage.getItem(storageKey) === 'seen';
    } catch {
      // The tutorial remains usable for the current session when browser storage is unavailable.
    }
    setSession({ key: storageKey, openedFrom: seen ? null : 'home' });
  }, [homePath, pathname, ready, session?.key, storageKey]);

  function open() {
    if (storageKey) setSession({ key: storageKey, openedFrom: 'settings' });
  }

  function close() {
    if (!storageKey) return;
    setSession({ key: storageKey, openedFrom: null });
    try {
      window.localStorage.setItem(storageKey, 'seen');
    } catch {
      // Keep the dismissal in React state even if the browser cannot keep it across reloads.
    }
  }

  return (
    <TutorialContext.Provider value={accountId ? { buttonId, open } : null}>
      {children}
      {ready && openedFrom && (
        <TutorialDialog title={`${appName} tutorial`} pages={pages} onClose={close}
          returnFocusId={openedFrom === 'settings' ? buttonId : undefined} />
      )}
    </TutorialContext.Provider>
  );
}

export function TutorialButton() {
  const tutorial = useContext(TutorialContext);
  if (!tutorial) return null;

  return <HelpButton id={tutorial.buttonId} icon={BookOpen} label="View tutorial" onClick={tutorial.open} />;
}

export function HelpSection({ appName, sections, className = '' }: {
  appName: string;
  sections: readonly FeatureSection[];
  className?: string;
}) {
  const headingId = useId();
  const featuresButtonId = useId();
  const [featuresOpen, setFeaturesOpen] = useState(false);

  return (
    <section className={`ui-section-card app-settings-help ${className}`} aria-labelledby={headingId}>
      <h2 id={headingId} className="ui-section-title">Help</h2>
      <TutorialButton />
      <HelpButton id={featuresButtonId} icon={ListChecks} label="Detailed functionalities" onClick={() => setFeaturesOpen(true)} />
      <Dialog open={featuresOpen} onClose={() => setFeaturesOpen(false)} title={`${appName} features`} returnFocusId={featuresButtonId}>
        <div className="app-feature-guide">
          {sections.map(section => (
            <details key={section.title} className="app-feature-section">
              <summary className="app-feature-summary">
                <span>{section.title}</span>
                <ChevronDown size={18} aria-hidden="true" />
              </summary>
              <dl className="app-feature-entries">
                {section.entries.map(entry => (
                  <div key={entry.title}>
                    <dt>{entry.title}</dt>
                    <dd>
                      <p>{entry.text}</p>
                      {entry.formula && <code>{entry.formula}</code>}
                    </dd>
                  </div>
                ))}
              </dl>
            </details>
          ))}
        </div>
      </Dialog>
    </section>
  );
}

function HelpButton({ id, icon: Icon, label, onClick }: { id: string; icon: LucideIcon; label: string; onClick: () => void }) {
  return (
    <button type="button" id={id} aria-haspopup="dialog" onClick={onClick}
      className="ui-setting-action ui-interactive-surface cursor-pointer border border-ui-border bg-ui-surface">
      <span className="ui-setting-label">
        <span className="ui-setting-icon"><Icon size={18} aria-hidden="true" /></span>
        <span>{label}</span>
      </span>
      <ChevronRight size={18} className="text-ui-muted" aria-hidden="true" />
    </button>
  );
}

function TutorialDialog({ title, pages, onClose, returnFocusId }: {
  title: string;
  pages: TutorialPages;
  onClose: () => void;
  returnFocusId?: string;
}) {
  const [index, setIndex] = useState(0);
  const descriptionId = useId();
  const pageRef = useRef<HTMLDivElement>(null);
  const nextButton = useRef<HTMLButtonElement>(null);
  const page = pages[index];
  const lastPage = index === pages.length - 1;

  useLayoutEffect(() => {
    const body = pageRef.current?.closest('.app-dialog-body');
    if (body) body.scrollTop = 0;
  }, [index]);

  function back() {
    if (index === 1) nextButton.current?.focus();
    setIndex(index - 1);
  }

  return (
    <Dialog open title={title} onClose={onClose} returnFocusId={returnFocusId} descriptionId={descriptionId}>
      <div ref={pageRef} id={descriptionId} className="app-tutorial-page" aria-live="polite" aria-atomic="true">
        <div className="app-tutorial-page-top">
          {'logo' in page ? (
            <img className="app-tutorial-logo" src={page.logo} alt="" width={44} height={44} />
          ) : (
            <span className="app-tutorial-icon"><page.icon size={24} aria-hidden="true" /></span>
          )}
          <p className="ui-meta">Page {index + 1} of {pages.length}</p>
        </div>
        <h3 className="app-tutorial-page-title">{page.title}</h3>
        {'description' in page ? (
          <p className="app-tutorial-description">{page.description}</p>
        ) : (
          <ul className="app-tutorial-actions" aria-label={`${page.title} features`}>
            {page.actions.map(({ icon: Icon, text, primary }) => (
              <li key={text} className="app-tutorial-action">
                <span className="app-tutorial-action-icon" data-primary={primary}>
                  <Icon size={16} aria-hidden="true" />
                </span>
                <span>{text}</span>
              </li>
            ))}
          </ul>
        )}
        {'legend' in page && page.legend && (
          <ul className="app-tutorial-legend" aria-label={`${page.title} colour key`}>
            {page.legend.map(({ color, text }) => (
              <li key={text}>
                <span className="app-tutorial-swatch" style={{ background: color }} aria-hidden="true" />
                <span>{text}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
      <DialogActions>
        <button type="button" className="ui-button ui-button-secondary" disabled={index === 0} onClick={back}>Back</button>
        <button type="button" className="ui-button ui-button-primary" ref={nextButton}
          onClick={lastPage ? onClose : () => setIndex(index + 1)}>
          {lastPage ? 'Done' : 'Next'}
        </button>
      </DialogActions>
    </Dialog>
  );
}
