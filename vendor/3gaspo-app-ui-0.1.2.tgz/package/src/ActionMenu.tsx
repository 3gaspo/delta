import { useEffect, useId, useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { useDialogOwner } from './Dialog';
type Action = { label: string; onSelect: () => void | Promise<unknown>; icon?: ReactNode; disabled?: boolean; destructive?: boolean };
export function ActionMenu({ label, items, icon, triggerId, triggerClassName }: { label: string; items: Action[]; icon: ReactNode; triggerId?: string; triggerClassName?: string }) {
  const id = useId(), owner = useDialogOwner(), trigger = useRef<HTMLButtonElement>(null), menu = useRef<HTMLDivElement>(null), pending = useRef(false);
  const [open, setOpen] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState(''), [position, setPosition] = useState({ left: 8, top: 8, maxHeight: 300 });
  const close = (restore = true) => { setOpen(false); setError(''); if (restore) trigger.current?.focus({ preventScroll: true }); };
  useLayoutEffect(() => {
    if (!open) return;
    const update = () => {
      const anchor = trigger.current?.getBoundingClientRect(), panel = menu.current;
      if (!anchor || !panel) return;
      const viewport = window.visualViewport, width = viewport?.width || innerWidth, height = viewport?.height || innerHeight;
      const offsetX = viewport?.offsetLeft || 0, offsetY = viewport?.offsetTop || 0;
      const rect = panel.getBoundingClientRect(), availableBelow = height + offsetY - anchor.bottom - 16, availableAbove = anchor.top - offsetY - 16;
      const below = availableBelow >= rect.height || availableBelow >= availableAbove;
      const maxHeight = Math.min(height - 16, Math.max(44, (below ? availableBelow : availableAbove)));
      const top = below ? anchor.bottom + 8 : anchor.top - Math.min(rect.height, maxHeight) - 8;
      setPosition({ left: Math.max(offsetX + 8, Math.min(anchor.right - rect.width, offsetX + width - rect.width - 8)), top: Math.max(offsetY + 8, Math.min(top, offsetY + height - Math.min(rect.height, maxHeight) - 8)), maxHeight });
    };
    update(); menu.current?.querySelector<HTMLButtonElement>('button:not(:disabled)')?.focus({ preventScroll: true });
    const outside = (event: PointerEvent) => { if (!menu.current?.contains(event.target as Node) && !trigger.current?.contains(event.target as Node) && !busy) close(false); };
    window.addEventListener('resize', update); window.addEventListener('scroll', update, true); document.addEventListener('pointerdown', outside, true);window.visualViewport?.addEventListener('resize', update);
    return () => { window.removeEventListener('resize', update); window.removeEventListener('scroll', update, true); document.removeEventListener('pointerdown', outside, true);window.visualViewport?.removeEventListener('resize', update); };
  }, [open, busy, error]);
  useEffect(() => { if (!open) setError(''); }, [open]);
  return <>
    <button ref={trigger} id={triggerId} type="button" title={label} aria-label={label} aria-haspopup="menu" aria-expanded={open} aria-controls={open ? id : undefined} className={triggerClassName || 'ui-icon-button ui-action-menu-trigger'} disabled={busy} onClick={() => setOpen(previous => !previous)} onKeyDown={event => { if (event.key === 'ArrowDown' || event.key === 'ArrowUp') { event.preventDefault(); setOpen(true); } }}>{icon}</button>
    {open && createPortal(<div ref={menu} id={id} role="menu" aria-label={label} className="ui-action-menu" data-dialog-owner={owner} style={position} onKeyDown={event => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); if (!busy) close(); return; }
      if (event.key === 'Tab') { event.preventDefault(); if (!busy) close(); return; }
      if (!['ArrowDown','ArrowUp','Home','End'].includes(event.key)) return;
      event.preventDefault(); const buttons = Array.from(menu.current?.querySelectorAll('button:not(:disabled)') || []) as HTMLButtonElement[];
      const current = buttons.indexOf(document.activeElement as HTMLButtonElement), next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 : (current + (event.key === 'ArrowUp' ? -1 : 1) + buttons.length) % buttons.length;
      buttons[next]?.focus();
    }}>{items.map(item => <button key={item.label} type="button" role="menuitem" disabled={busy || item.disabled} className={`ui-action-menu-item ${item.destructive ? 'ui-action-menu-item--danger' : ''}`} onClick={async () => {
      if (pending.current) return; pending.current = true; setBusy(true);setError('');
      try { await item.onSelect(); close(); } catch (failure) { setError(failure instanceof Error ? failure.message : 'Could not save. Try again.'); } finally { pending.current = false; setBusy(false); }
    }}>{item.icon}{item.label}</button>)}{error && <p className="ui-error" role="alert">{error}</p>}{busy && <p className="ui-form-status" role="status">Saving…</p>}</div>, document.body)}
  </>;
}
