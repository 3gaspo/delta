import { AlertCircle, Inbox, LoaderCircle } from 'lucide-react';
import type { ReactNode } from 'react';

export function StateFeedback({ kind = 'empty', title, children }: {
  kind?: 'empty' | 'loading' | 'error';
  title?: string;
  children?: ReactNode;
}) {
  const Icon = kind === 'loading' ? LoaderCircle : kind === 'error' ? AlertCircle : Inbox;
  return <div className={`ui-state ui-state-${kind}`} role={kind === 'error' ? 'alert' : 'status'} aria-live={kind === 'error' ? 'assertive' : 'polite'}>
    <Icon aria-hidden="true" className={`ui-state-icon${kind === 'loading' ? ' ui-state-loading' : ''}`} />
    <p className="ui-state-title">{title ?? (kind === 'loading' ? 'Loading…' : kind === 'error' ? 'Load failed' : 'No data')}</p>
    {children}
  </div>;
}
