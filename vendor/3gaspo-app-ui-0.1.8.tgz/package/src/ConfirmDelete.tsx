import { Dialog, DialogActions } from './Dialog';
import { ActionButton } from './ActionButton';
import type { ReactNode } from 'react';

export function ConfirmDelete({ open, onClose, onConfirm, title, children }: {
  open: boolean; onClose: () => void; onConfirm: () => unknown; title: string; children: ReactNode;
}) {
  return <Dialog open={open} onClose={onClose} title={title}>
    <div className="ui-confirm-description">{children}</div>
    <DialogActions>
      <button type="button" className="ui-button ui-button-secondary" onClick={onClose}>Cancel</button>
      <ActionButton className="ui-button ui-button-danger" busyLabel="Deleting…" onClick={onConfirm}>Delete</ActionButton>
    </DialogActions>
  </Dialog>;
}
