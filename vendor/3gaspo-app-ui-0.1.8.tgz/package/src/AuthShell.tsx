import { useEffect, useId, useRef, type ReactNode } from 'react';
import { createPortal } from 'react-dom';

export function AuthShell({ appName, logo, modal = false, children }: { appName: string; logo: string; modal?: boolean; children: ReactNode }) {
  const titleId = useId(), surface = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!modal) return;
    const previousFocus = document.activeElement as HTMLElement | null, overflow = document.body.style.overflow;
    const nodes = Array.from(document.body.children).filter((node): node is HTMLElement => node instanceof HTMLElement && node !== surface.current);
    const inert = nodes.map(node => node.inert);
    nodes.forEach(node => { node.inert = true; }); document.body.style.overflow = 'hidden';
    surface.current?.querySelector<HTMLElement>('input')?.focus();
    return () => { nodes.forEach((node, i) => { node.inert = inert[i]; }); document.body.style.overflow = overflow; if (previousFocus?.isConnected) previousFocus.focus(); };
  }, [modal]);
  const content = <div ref={surface} className={`ui-auth-shell ${modal ? 'ui-auth-shell--modal' : ''}`} role={modal ? 'dialog' : undefined} aria-modal={modal || undefined} aria-labelledby={modal ? titleId : undefined} onKeyDown={event => {
    if (!modal || event.key !== 'Tab') return;
    const nodes = Array.from(surface.current?.querySelectorAll('input, button:not(:disabled), a[href]') || []) as HTMLElement[];
    const first = nodes[0], last = nodes.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
  }}>
    <div className="ui-auth-card">
      <header className="ui-auth-brand"><img src={logo} alt="" width={48} height={48} /><h1 id={titleId} className="app-brand-title">{appName}</h1></header>
      {children}
    </div>
  </div>;
  return modal ? createPortal(content, document.body) : content;
}
