import { createContext, useContext, useId, useLayoutEffect, useRef, useState, type ReactNode, type ReactElement, Children, isValidElement, cloneElement } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';

type Entry = { id: string; layer: HTMLElement; panel: HTMLElement };
const stack: Entry[] = [];
const inertValues = new Map<HTMLElement, boolean>();
let bodyLock: { css: string; x: number; y: number; opener: HTMLElement | null } | undefined;
const DialogContext = createContext<{ id: string; footer: HTMLElement | null; close: () => void; busy: boolean } | undefined>(undefined);

function syncBackground() {
  for (const [node, inert] of inertValues) node.inert = inert;
  inertValues.clear();
  const top = stack.at(-1);
  if (!top) return;
  for (const child of Array.from(document.body.children)) {
    if (!(child instanceof HTMLElement) || child === top.layer || child.dataset.dialogOwner === top.id) continue;
    inertValues.set(child, child.inert);
    child.inert = true;
  }
  stack.forEach((entry, index) => { entry.layer.style.zIndex = String(100 + index * 10); });
}

function roots(entry: Entry) {
  return [entry.panel, ...Array.from(document.querySelectorAll<HTMLElement>('[data-dialog-owner]')).filter(node => node.dataset.dialogOwner === entry.id)];
}

function focusable(entry: Entry) {
  return roots(entry).flatMap(root => Array.from(root.querySelectorAll<HTMLElement>('button, a[href], input, select, textarea, [tabindex]')))
    .filter(node => node.tabIndex >= 0 && !node.matches(':disabled, [hidden], input[type="hidden"]') && !node.closest('[inert], .sr-only') && node.getClientRects().length > 0 && getComputedStyle(node).visibility !== 'hidden');
}

export function useDialogOwner() { return useContext(DialogContext)?.id; }

// Associated submit buttons keep their native form validation even in the footer portal.
function associateForm(children: ReactNode, form?: string): ReactNode {
  if (!form) return children;
  return Children.map(children, child => {
    if (!isValidElement(child)) return child;
    const element = child as ReactElement<{ type?: string; form?: string; children?: ReactNode }>;
    return cloneElement(element, {
      ...(element.props.type === 'submit' && !element.props.form ? { form } : {}),
      ...(element.props.children !== undefined ? { children: associateForm(element.props.children, form) } : {}),
    });
  });
}

export function DialogActions({ children, form, cancel = false }: { children: ReactNode; form?: string; cancel?: boolean }) {
  const dialog = useContext(DialogContext);
  const content = <div className="app-dialog-actions">
    <fieldset disabled={dialog?.busy} className="app-dialog-action-group">
    {cancel && dialog && <button type="button" disabled={dialog.busy} onClick={dialog.close} className="app-dialog-cancel">Cancel</button>}
    {associateForm(children, form)}
    </fieldset>
  </div>;
  if (!dialog) return content;
  return dialog.footer ? createPortal(content, dialog.footer) : null;
}

interface DialogProps {
  open: boolean;
  onClose: () => void;
  title: ReactNode;
  children: ReactNode;
  busy?: boolean;
  id?: string;
  closeButtonId?: string;
  returnFocusId?: string;
}

export function Dialog({ open, onClose, title, children, busy = false, id, closeButtonId, returnFocusId }: DialogProps) {
  const dialogId = useId();
  const titleId = `${dialogId}-title`;
  const layerRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const outsidePointer = useRef(false);
  const openingElement = useRef<HTMLElement | null>(null);
  const wasOpen = useRef(false);
  if (open && !wasOpen.current && typeof document !== 'undefined') openingElement.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  wasOpen.current = open;
  const [formBusy, setFormBusy] = useState(false);
  const isBusy = busy || formBusy;
  const latest = useRef({ onClose, busy: isBusy, returnFocusId });
  latest.current = { onClose, busy: isBusy, returnFocusId };
  const [footer, setFooter] = useState<HTMLDivElement | null>(null);
  const [viewport, setViewport] = useState<{ top: number; height: number } | undefined>();
  const close = () => { if (!latest.current.busy) latest.current.onClose(); };

  useLayoutEffect(() => {
    if (!open || !panelRef.current) return;
    const panel = panelRef.current;
    const sync = () => setFormBusy(!!panel.querySelector('.ui-form[aria-busy="true"], [data-ui-action][aria-busy="true"]'));
    const observer = new MutationObserver(sync);
    observer.observe(panel, { subtree: true, childList: true, attributes: true, attributeFilter: ['aria-busy'] });
    sync();
    return () => { observer.disconnect(); setFormBusy(false); };
  }, [open]);

  useLayoutEffect(() => {
    if (!open || !layerRef.current || !panelRef.current) return;
    const opener = openingElement.current;
    const entry = { id: dialogId, layer: layerRef.current, panel: panelRef.current };
    if (!stack.length) {
      bodyLock = { css: document.body.style.cssText, x: window.scrollX, y: window.scrollY, opener };
      const scrollbar = window.innerWidth - document.documentElement.clientWidth;
      const padding = parseFloat(getComputedStyle(document.body).paddingRight) || 0;
      Object.assign(document.body.style, { overflow: 'hidden', position: 'fixed', top: `${-window.scrollY}px`, left: `${-window.scrollX}px`, width: '100%', paddingRight: `${padding + scrollbar}px` });
    }
    stack.push(entry);
    syncBackground();
    const focusFrame = requestAnimationFrame(() => {
      if (stack.at(-1) === entry && !roots(entry).some(root => root.contains(document.activeElement))) titleRef.current?.focus({ preventScroll: true });
    });
    const keydown = (event: KeyboardEvent) => {
      if (stack.at(-1) !== entry || event.defaultPrevented) return;
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopPropagation();
        close();
      } else if (event.key === 'Tab') {
        const nodes = focusable(entry);
        const index = nodes.indexOf(document.activeElement as HTMLElement);
        if (!nodes.length) { event.preventDefault(); titleRef.current?.focus(); }
        else if (index < 0 || (!event.shiftKey && index === nodes.length - 1) || (event.shiftKey && index === 0)) {
          event.preventDefault();
          nodes[event.shiftKey ? nodes.length - 1 : 0].focus();
        }
      }
    };
    const focusin = (event: FocusEvent) => {
      if (stack.at(-1) === entry && !roots(entry).some(root => root.contains(event.target as Node))) titleRef.current?.focus({ preventScroll: true });
    };
    let viewportFrame = 0;
    const updateViewport = () => {
      const visual = window.visualViewport;
      if (visual) setViewport({ top: visual.offsetTop, height: visual.height });
      cancelAnimationFrame(viewportFrame);
      viewportFrame = requestAnimationFrame(() => {
        const active = document.activeElement;
        if (stack.at(-1) === entry && active instanceof HTMLElement && entry.panel.querySelector('.app-dialog-body')?.contains(active)) active.scrollIntoView({ block: 'nearest' });
      });
    };
    updateViewport();
    document.addEventListener('keydown', keydown);
    document.addEventListener('focusin', focusin);
    window.visualViewport?.addEventListener('resize', updateViewport);
    window.visualViewport?.addEventListener('scroll', updateViewport);
    return () => {
      cancelAnimationFrame(focusFrame);
      cancelAnimationFrame(viewportFrame);
      document.removeEventListener('keydown', keydown);
      document.removeEventListener('focusin', focusin);
      window.visualViewport?.removeEventListener('resize', updateViewport);
      window.visualViewport?.removeEventListener('scroll', updateViewport);
      const wasTop = stack.at(-1) === entry;
      const index = stack.indexOf(entry);
      if (index >= 0) stack.splice(index, 1);
      syncBackground();
      const initialOpener = bodyLock?.opener;
      if (!stack.length && bodyLock) {
        const { css, x, y } = bodyLock;
        bodyLock = undefined;
        document.body.style.cssText = css;
        window.scrollTo(x, y);
      }
      if (wasTop) requestAnimationFrame(() => {
        if (stack.some(item => item.id === dialogId)) return;
        const fallback = latest.current.returnFocusId ? document.getElementById(latest.current.returnFocusId) : null;
        // Explicit targets also avoid focusing an opener that is still animating out.
        const target = fallback?.isConnected && !fallback.closest('[inert]') ? fallback
          : opener?.isConnected && !opener.closest('[inert]') ? opener
          : !stack.length ? initialOpener : null;
        if (target?.isConnected) target.focus({ preventScroll: true });
        else if (stack.length) stack.at(-1)?.panel.focus({ preventScroll: true });
      });
    };
  }, [open, dialogId]);

  if (!open) return null;
  return createPortal(
    <DialogContext.Provider value={{ id: dialogId, footer, close, busy: isBusy }}>
      <div ref={layerRef} className="app-dialog-layer" data-dialog-layer="" style={viewport ? { top: viewport.top, height: viewport.height } : undefined}
        onPointerDown={event => { outsidePointer.current = event.target === event.currentTarget; }}
        onClick={event => {
          if (outsidePointer.current && event.target === event.currentTarget && stack.at(-1)?.id === dialogId) close();
          outsidePointer.current = false;
        }}>
        <div ref={panelRef} id={id} role="dialog" aria-modal="true" aria-labelledby={titleId} aria-busy={isBusy || undefined} tabIndex={-1} className="app-dialog" onClickCapture={event => {
          if (latest.current.busy && (event.target as HTMLElement).closest('button')) { event.preventDefault(); event.stopPropagation(); }
        }}>
          <header className="app-dialog-header">
            <h2 ref={titleRef} id={titleId} tabIndex={-1} className="app-dialog-title">{title}</h2>
            <button type="button" id={closeButtonId} disabled={isBusy} onClick={close} aria-label="Close modal" className="app-dialog-close"><X size={24} aria-hidden="true" /></button>
          </header>
          <div className="app-dialog-body">{children}</div>
          <div ref={setFooter} className="app-dialog-footer" />
        </div>
      </div>
    </DialogContext.Provider>, document.body,
  );
}
