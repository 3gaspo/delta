import { useId, useRef, useState } from 'react';
import { Eye, EyeOff, Lock, Mail } from 'lucide-react';
import { ValidatedForm } from './ValidatedForm';

type Props = { onAuthenticate: (email: string, password: string, signUp: boolean) => Promise<unknown>; allowUsername?: boolean };
export function AuthForm({ onAuthenticate, allowUsername = false }: Props) {
  const id = useId(), pending = useRef(false);
  const [email, setEmail] = useState(''), [password, setPassword] = useState(''), [show, setShow] = useState(false), [signUp, setSignUp] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState('');
  return <div className="ui-auth-fields">
    <div className="ui-segments" role="group" aria-label="Account access">
      <button type="button" className="ui-option" aria-pressed={!signUp} disabled={busy} onClick={() => { setSignUp(false); setError(''); }}>Sign in</button>
      <button type="button" className="ui-option" aria-pressed={signUp} disabled={busy} onClick={() => { setSignUp(true); setError(''); }}>Create account</button>
    </div>
    <ValidatedForm className="ui-auth-fields" busyLabel={signUp ? 'Creating account…' : 'Signing in…'} onSubmit={async () => {
      if (pending.current) return;
      pending.current = true; setBusy(true); setError('');
      try { await onAuthenticate(email.trim(), password, signUp); }
      catch (failure) { setError(failure instanceof Error ? failure.message : 'Could not sign in. Try again.'); }
      finally { pending.current = false; setBusy(false); }
    }}>
      <div className="ui-auth-field">
        <label className="ui-field-label" htmlFor={`${id}-email`}>{allowUsername ? 'Email or username' : 'Email address'}</label>
        <div className="ui-auth-input"><Mail aria-hidden="true" size={20} /><input id={`${id}-email`} name="email" type={allowUsername ? 'text' : 'email'} autoComplete="username" autoCapitalize="none" spellCheck={false} required readOnly={busy} value={email} onChange={event => setEmail(event.target.value)} className="ui-field ui-field-leading" /></div>
      </div>
      <div className="ui-auth-field">
        <label className="ui-field-label" htmlFor={`${id}-password`}>Password</label>
        <div className="ui-auth-input"><Lock aria-hidden="true" size={20} /><input id={`${id}-password`} name="password" type={show ? 'text' : 'password'} autoComplete={signUp ? 'new-password' : 'current-password'} required readOnly={busy} value={password} onChange={event => setPassword(event.target.value)} className="ui-field ui-field-leading ui-field-trailing" />
          <button type="button" className="ui-auth-password" aria-label={show ? 'Hide password' : 'Show password'} aria-pressed={show} onClick={() => setShow(previous => !previous)}>{show ? <EyeOff size={20} /> : <Eye size={20} />}</button>
        </div>
      </div>
      {error && <p className="ui-error" role="alert">{error}</p>}
      <button className="ui-button ui-button-primary ui-auth-submit" type="submit" disabled={busy}>{signUp ? 'Create account' : 'Sign in'}</button>
    </ValidatedForm>
  </div>;
}
