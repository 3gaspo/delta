import { Search, X } from 'lucide-react';
export function SearchField({ value, onChange, label, id }: { value: string; onChange: (value: string) => void; label: string; id?: string }) {
  return <div className="ui-search">
    <Search size={20} aria-hidden="true" />
    <input id={id} className="ui-field ui-field-leading ui-field-trailing" type="search" value={value} onChange={event => onChange(event.target.value)} aria-label={label} placeholder="Search" autoComplete="off" />
    {value && <button className="ui-search-clear" type="button" aria-label="Clear search" onClick={event => { onChange(''); event.currentTarget.parentElement?.querySelector('input')?.focus(); }}><X size={18} /></button>}
  </div>;
}
