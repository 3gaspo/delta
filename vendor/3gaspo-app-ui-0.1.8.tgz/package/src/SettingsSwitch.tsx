import type { ReactNode } from 'react';

function Indicator({ checked }: { checked: boolean }) {
  return <span className="ui-switch-track" data-checked={checked} aria-hidden="true"><span className="ui-switch-thumb" /></span>;
}

type Props = { checked: boolean; onClick: () => void; label: string; id?: string; title?: string; disabled?: boolean };
export function SettingsSwitch({ checked, onClick, label, id, title, disabled }: Props) {
  return <button type="button" role="switch" aria-label={label} aria-checked={checked} id={id} title={title} disabled={disabled} onClick={onClick} className="ui-switch-control"><Indicator checked={checked} /></button>;
}
export function SettingsToggle({ checked, onClick, label, id, disabled, icon }: Props & { icon?: ReactNode }) {
  return <button type="button" role="switch" aria-label={label} aria-checked={checked} id={id} disabled={disabled} onClick={onClick} className="ui-setting-row ui-setting-toggle">
    <span className="ui-setting-label">{icon && <span className="ui-setting-icon">{icon}</span>}<span>{label}</span></span><Indicator checked={checked} />
  </button>;
}
