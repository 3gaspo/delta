// Display conventions only. Storage keys, calculations and CSV values stay in each app.
export const UI_LOCALE = 'en-GB';
type DateValue = Date | string | number;
function displayDate(value: DateValue) {
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
    const [year, month, day] = value.split('-').map(Number);
    const date = new Date(year, month - 1, day);
    return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day ? date : new Date(NaN);
  }
  return value instanceof Date ? value : new Date(value);
}
const dates = new Map<string, Intl.DateTimeFormat>();
function dateText(value: DateValue, options: Intl.DateTimeFormatOptions) {
  const date = displayDate(value);
  if (!Number.isFinite(date.getTime())) return '—';
  const key = JSON.stringify(options);
  if (!dates.has(key)) dates.set(key, new Intl.DateTimeFormat(UI_LOCALE, options));
  return dates.get(key)!.format(date);
}
export function formatDate(value: DateValue, style: 'short' | 'long' | 'full' | 'compact' = 'short') {
  return dateText(value, { ...(style === 'full' ? { weekday: 'long' as const } : {}), day: 'numeric', month: style === 'long' || style === 'full' ? 'long' : 'short', ...(style === 'compact' ? {} : { year: 'numeric' as const }) });
}
export function formatMonth(value: DateValue) { return dateText(value, { month: 'long', year: 'numeric' }); }
export function formatMonthName(value: DateValue) { return dateText(value, { month: 'short' }); }
export function formatWeekday(value: DateValue) { return dateText(value, { weekday: 'short' }); }
export function formatTime(value: DateValue) { return dateText(value, { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }); }
const numbers = new Map<string, Intl.NumberFormat>();
export function formatNumber(value: number, digits = 0) {
  if (!Number.isFinite(value)) return '—';
  const key = String(digits);
  if (!numbers.has(key)) numbers.set(key, new Intl.NumberFormat(UI_LOCALE, { minimumFractionDigits: digits, maximumFractionDigits: digits }));
  return numbers.get(key)!.format(value);
}
export function formatPercent(value: number, scale: 'ratio' | 'percent' = 'ratio', digits = 0) {
  return Number.isFinite(value) ? `${formatNumber(scale === 'ratio' ? value * 100 : value, digits)}%` : '—';
}
export function formatCurrency(amount: number, currency = 'EUR') {
  const code = (currency || 'EUR').toUpperCase();
  const digits = ['JPY', 'KRW', 'VND', 'CLP', 'PYG', 'UGX', 'RWF'].includes(code) ? 0 : 2;
  if (!Number.isFinite(amount)) return '—';
  try { return new Intl.NumberFormat(UI_LOCALE, { style: 'currency', currency: code, minimumFractionDigits: digits, maximumFractionDigits: digits }).format(amount); }
  catch { return `${code} ${formatNumber(amount, digits)}`; }
}
