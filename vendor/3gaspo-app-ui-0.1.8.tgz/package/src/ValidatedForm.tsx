import { useId, useLayoutEffect, useRef, useState, type FormHTMLAttributes, type FormEvent } from 'react';

type Field = HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;
type Issue = { field: Field; id: string; message: string };
type Props = Omit<FormHTMLAttributes<HTMLFormElement>, 'onSubmit'> & {
  onSubmit?: (event: FormEvent<HTMLFormElement>) => void | Promise<unknown>;
  busyLabel?: string;
};

function message(field: Field) {
  const v = field.validity;
  if (v.valueMissing || (field.required && !field.value.trim())) return 'Required';
  if (v.typeMismatch) return field instanceof HTMLInputElement && field.type === 'email' ? 'Enter a valid email' : 'Check this value';
  if (v.rangeUnderflow) return `Minimum: ${field.getAttribute('min')}`;
  if (v.rangeOverflow) return `Maximum: ${field.getAttribute('max')}`;
  if (v.tooShort) return `Minimum: ${field.getAttribute('minlength')} characters`;
  if (v.tooLong) return `Maximum: ${field.getAttribute('maxlength')} characters`;
  if (v.badInput || v.stepMismatch) return 'Enter a valid number';
  return field.validationMessage || 'Check this value';
}

export function ValidatedForm({ onSubmit, onInputCapture, children, className = '', busyLabel = 'Saving…', ...props }: Props) {
  const uid = useId(), formRef = useRef<HTMLFormElement>(null), submitting = useRef(false), focusIssues = useRef(false);
  const [issues, setIssues] = useState<Issue[]>([]), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  useLayoutEffect(() => {
    for (const issue of issues) {
      issue.field.setAttribute('aria-invalid', 'true');
      issue.field.setAttribute('aria-describedby', [...new Set([...(issue.field.getAttribute('aria-describedby') || '').split(' ').filter(Boolean), issue.id])].join(' '));
    }
    if (focusIssues.current) { issues[0]?.field.focus(); issues[0]?.field.scrollIntoView({ block: 'nearest' }); focusIssues.current = false; }
    return () => { for (const issue of issues) {
      issue.field.removeAttribute('aria-invalid');
      const ids = (issue.field.getAttribute('aria-describedby') || '').split(' ').filter(id => id && id !== issue.id);
      if (ids.length) issue.field.setAttribute('aria-describedby', ids.join(' ')); else issue.field.removeAttribute('aria-describedby');
    } };
  }, [issues]);
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (submitting.current) return;
    const form = event.currentTarget;
    const fields = Array.from(form.elements).filter((element): element is Field => element instanceof HTMLInputElement || element instanceof HTMLSelectElement || element instanceof HTMLTextAreaElement);
    const invalid = fields.filter(field => field.willValidate && (!field.validity.valid || (field.required && !field.value.trim()))).map((field, i) => {
      if (!field.id) field.id = `${uid}-field-${fields.indexOf(field)}`;
      const label = field.labels?.[0]?.textContent?.trim() || field.getAttribute('aria-label') || field.getAttribute('placeholder') || field.name || 'Field';
      return { field, id: `${uid}-error-${i}`, message: `${label}: ${message(field)}` };
    });
    setIssues(invalid); setError('');
    if (invalid.length) { focusIssues.current = true; return; }
    submitting.current = true; setBusy(true);
    try { await onSubmit?.(event); }
    catch (failure) { setError(failure instanceof Error ? failure.message : 'Could not save. Try again.'); }
    finally {
      submitting.current = false; setBusy(false);
      requestAnimationFrame(() => {
        const alert = formRef.current?.querySelector<HTMLElement>('.ui-error[role="alert"]');
        if (alert) { alert.tabIndex = -1; alert.focus(); alert.scrollIntoView({ block: 'nearest' }); }
      });
    }
  };
  return <form {...props} ref={formRef} noValidate className={`ui-form ${className}`} aria-busy={busy} onSubmit={submit} onInputCapture={event => {
    onInputCapture?.(event);
    const field = event.target as Field;
    setIssues(previous => previous.filter(issue => issue.field !== field || !field.validity.valid));
    setError('');
  }}>
    {issues.length > 0 && <div className="ui-error ui-field-errors" role="alert">{issues.map(issue => <a key={issue.id} id={issue.id} href={`#${issue.field.id}`} onClick={event => { event.preventDefault(); issue.field.focus(); }}>{issue.message}</a>)}</div>}
    {children}
    {error && <p className="ui-error" role="alert">{error}</p>}
    {busy && <p className="ui-form-status" role="status">{busyLabel}</p>}
  </form>;
}
