type PageHeaderProps = {
  title: string;
  devMode?: boolean;
  titleId?: string;
  devModeId?: string;
  className?: string;
};

export function PageHeader({ title, devMode = false, titleId, devModeId, className = '' }: PageHeaderProps) {
  return (
    <header className={`ui-page-header ${className}`}>
      <h1 id={titleId}>{title}</h1>
      {devMode && <span id={devModeId} className="ui-dev-badge">Dev mode</span>}
    </header>
  );
}
