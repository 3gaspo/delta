import { NavLink } from 'react-router-dom';
import type { LucideIcon } from 'lucide-react';

export interface NavigationItem {
  to: string;
  label: string;
  icon: LucideIcon;
  id?: string;
}

export function BottomNavigation({ items, id }: { items: NavigationItem[]; id?: string }) {
  return (
    <nav id={id} aria-label="Primary" className="app-bottom-nav">
      <div className="app-bottom-nav__items">
        {items.map(({ to, label, icon: Icon, id: itemId }) => (
          <NavLink key={to} id={itemId} to={to}
            className={({ isActive }) => 'app-bottom-nav__link ' + (isActive ? 'text-ui-ink' : 'text-ui-ink/30')}
          >
            <Icon size={24} strokeWidth={2} aria-hidden="true" />
            <span className="app-bottom-nav__label">{label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
