import { Plus } from 'lucide-react';

interface FloatingAddButtonProps {
  label: string;
  onClick: () => void;
  id?: string;
  floating?: boolean;
  expanded?: boolean;
}

export function FloatingAddButton({ label, onClick, id, floating = true, expanded }: FloatingAddButtonProps) {
  return <button type="button" id={id} aria-label={label} title={label} aria-expanded={expanded}
    onClick={onClick} className={`${floating ? 'app-floating-actions ' : ''}app-add-button`}>
    <Plus size={28} aria-hidden="true" />
  </button>;
}
