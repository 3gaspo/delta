import type { CSSProperties } from 'react';

export const chartTooltipStyle: CSSProperties = {
  backgroundColor: 'var(--ui-overlay)', color: 'var(--ui-text)', border: '1px solid var(--ui-border)',
  borderRadius: 16, padding: 12, fontSize: 12, lineHeight: '18px', maxWidth: 220,
  boxShadow: '0 8px 24px rgb(0 0 0 / 12%)', whiteSpace: 'normal', overflowWrap: 'anywhere',
};
export const chartLabelStyle: CSSProperties = { color: 'var(--ui-text)', fontSize: 12, fontWeight: 600 };
