import { ChevronLeft, ChevronRight } from 'lucide-react';

export function CalendarHeader({ title, onPrevious, onNext, onToday, previousId, nextId, titleId }: { title: string; onPrevious: () => void; onNext: () => void; onToday?: () => void; previousId?: string; nextId?: string; titleId?: string }) {
  return <div className="ui-calendar-toolbar">
    <h2 id={titleId} className="ui-calendar-month" aria-live="polite">{title}</h2>
    <div className="ui-calendar-controls">
      {onToday && <button className="ui-calendar-today" type="button" onClick={onToday}>Today</button>}
      <button id={previousId} type="button" onClick={onPrevious} aria-label="Previous" title="Previous month"><ChevronLeft size={20} /></button>
      <button id={nextId} type="button" onClick={onNext} aria-label="Next" title="Next month"><ChevronRight size={20} /></button>
    </div>
  </div>;
}
