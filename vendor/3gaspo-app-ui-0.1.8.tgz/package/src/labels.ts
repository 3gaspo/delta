export const ACTIONS = { add: 'Add', edit: 'Edit', save: 'Save', saving: 'Saving…', cancel: 'Cancel', delete: 'Delete', deleting: 'Deleting…', reorder: 'Reorder', done: 'Done', search: 'Search', retry: 'Retry' } as const;
export function actionTitle(action: 'add' | 'edit' | 'delete', subject: string) { return `${ACTIONS[action]} ${subject}`; }
