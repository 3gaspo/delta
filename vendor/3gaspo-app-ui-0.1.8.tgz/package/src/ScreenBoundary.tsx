import { Component, type ReactNode } from 'react';
import { StateFeedback } from './StateFeedback';

export function ScreenError() {
  return <StateFeedback kind="error" title="Screen unavailable">
    <button type="button" className="ui-button ui-button-secondary" onClick={() => window.location.reload()}>Retry</button>
  </StateFeedback>;
}

// Route downloads can fail independently from authentication or saved data.
export class ScreenBoundary extends Component<{ children: ReactNode; fallback?: ReactNode }, { failed: boolean }> {
  declare props: Readonly<{ children: ReactNode; fallback?: ReactNode }>;
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() {
    if (this.state.failed) return this.props.fallback ?? <ScreenError />;
    return this.props.children;
  }
}
