import { useEffect, useRef, useState, useSyncExternalStore, type ButtonHTMLAttributes, type MouseEvent } from 'react';
import { createPortal } from 'react-dom';

const locks = new Set<string>();
const listeners = new Set<() => void>();
const subscribe = (listener: () => void) => { listeners.add(listener); return () => { listeners.delete(listener); }; };
const notify = () => listeners.forEach(listener => listener());

type Props = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onClick'> & {
  onClick?: (event: MouseEvent<HTMLButtonElement>) => unknown;
  busyLabel?: string;
  scope?: string;
};

/** Preserve the button's layout and business handler; protect asynchronous actions. */
export function ActionButton({ onClick, children, disabled, busyLabel = 'Saving…', scope, className = '', type = 'button', ...props }: Props) {
  const button = useRef<HTMLButtonElement>(null), alert = useRef<HTMLDivElement>(null), running = useRef(false);
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  const scopeBusy = useSyncExternalStore(subscribe, () => !!scope && locks.has(scope), () => false);
  useEffect(() => {
    if (error) { alert.current?.focus(); alert.current?.scrollIntoView({ block: 'nearest' }); }
  }, [error]);
  const click = async (event: MouseEvent<HTMLButtonElement>) => {
    if (running.current || (scope && locks.has(scope))) { event.preventDefault(); return; }
    running.current = true;
    if (scope) { locks.add(scope); notify(); }
    setError('');
    try {
      const result = onClick?.(event);
      if (result && typeof (result as Promise<unknown>).then === 'function') {
        setBusy(true);
        await result;
      }
    } catch {
      setError('Could not complete action. Try again.');
    } finally {
      running.current = false; setBusy(false);
      if (scope) { locks.delete(scope); notify(); }
    }
  };
  const dialogBody = button.current?.closest('[role="dialog"]')?.querySelector('.app-dialog-body');
  return <>
    <button {...props} ref={button} type={type} className={`ui-action-button ${className}`} data-ui-action="" disabled={disabled || busy || scopeBusy} aria-busy={busy || undefined} onClick={click}>
      {children}
      {busy && <span className="ui-action-progress" role="status">{busyLabel}</span>}
    </button>
    {error && createPortal(<div ref={alert} tabIndex={-1} role="alert" className={`ui-error ui-action-error ${dialogBody ? '' : 'ui-action-error--floating'}`} onClick={event => event.stopPropagation()}>
      <p>{error}</p>
      <div className="ui-action-error__actions">
        <button type="button" className="ui-button ui-button-secondary" onClick={() => { setError(''); button.current?.focus(); button.current?.click(); }}>Retry</button>
        <button type="button" className="ui-button ui-button-ghost" onClick={() => { setError(''); button.current?.focus(); }}>Dismiss</button>
      </div>
    </div>, dialogBody || document.body)}
  </>;
}
