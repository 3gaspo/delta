export const DEFAULT_DARK_MODE = true;
export const DEFAULT_THEME = DEFAULT_DARK_MODE ? 'dark' : 'light';
