import { AlertCircle, Inbox, LoaderCircle } from 'lucide-react';
import type { ReactNode } from 'react';

export function StateFeedback({ kind = 'empty', title, children }: {
  kind?: 'empty' | 'loading' | 'error';
  title?: string;
  children?: ReactNode;
}) {
  const Icon = kind === 'loading' ? LoaderCircle : kind === 'error' ? AlertCircle : Inbox;
  return <div className={`ui-state ui-state-${kind}`} role={kind === 'error' ? 'alert' : 'status'} aria-live={kind === 'error' ? 'assertive' : 'polite'}>
    <Icon aria-hidden="true" className={`ui-state-icon${kind === 'loading' ? ' ui-state-spinner' : ''}`} />
    <p className={kind === 'loading' ? 'ui-visually-hidden' : 'ui-state-title'}>{title ?? (kind === 'loading' ? 'Loading…' : kind === 'error' ? 'Load failed' : 'No data')}</p>
    {children}
  </div>;
}

export function DataLoadError() {
  return <StateFeedback kind="error" title="Could not load data.">
    <button type="button" className="ui-button ui-button-secondary" onClick={() => window.location.reload()}>Reload page</button>
  </StateFeedback>;
}
