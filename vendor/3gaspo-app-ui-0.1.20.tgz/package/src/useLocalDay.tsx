import { useEffect, useState } from 'react';

const midnight = () => {
  const day = new Date();
  day.setHours(0, 0, 0, 0);
  return day;
};

/** Calendar day in the user's timezone; refresh after midnight, sleep or focus. */
export function useLocalDay(): Date {
  const [day, setDay] = useState(midnight);
  useEffect(() => {
    const refresh = () => {
      const next = midnight();
      setDay(previous => previous.getTime() === next.getTime() ? previous : next);
    };
    const tomorrow = new Date(day);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const timer = window.setTimeout(refresh, Math.max(1, tomorrow.getTime() - Date.now()));
    window.addEventListener('focus', refresh);
    document.addEventListener('visibilitychange', refresh);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('focus', refresh);
      document.removeEventListener('visibilitychange', refresh);
    };
  }, [day]);
  return day;
}
