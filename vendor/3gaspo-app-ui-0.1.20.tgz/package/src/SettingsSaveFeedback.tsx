import { useCallback, useEffect, useRef, useState } from 'react';
import { StateFeedback } from './StateFeedback';

type Operation = () => Promise<void>;

/** Observe event-handler promises, serialize settings writes and keep failed changes retryable. */
export function useSettingsSave() {
  const queue = useRef(Promise.resolve());
  const mounted = useRef(true);
  const versions = useRef(new Map<string, number>());
  const failed = useRef(new Map<string, Operation>());
  const [pending, setPending] = useState(0);
  const [errors, setErrors] = useState(0);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  const save = useCallback((operation: Operation, key = 'settings'): Promise<void> => {
    const version = (versions.current.get(key) ?? 0) + 1;
    versions.current.set(key, version);
    failed.current.delete(key);
    if (mounted.current) { setPending(count => count + 1); setErrors(failed.current.size); }
    const write = queue.current.then(operation);
    const observed = write.then(() => {}, () => {
      if (versions.current.get(key) === version) failed.current.set(key, operation);
    }).finally(() => {
      if (mounted.current) { setPending(count => count - 1); setErrors(failed.current.size); }
    });
    queue.current = observed;
    return observed;
  }, []);
  const retry = useCallback(() => Promise.all([...failed.current].map(([key, operation]) => save(operation, key))).then(() => {}), [save]);
  return { save, saving: pending > 0, error: errors > 0, retry };
}

export function SettingsSaveFeedback({ saving, error, retry }: {
  saving: boolean; error: boolean; retry: () => Promise<void>;
}) {
  return <>
    {saving && <StateFeedback kind="loading" title="Saving settings…" />}
    {error && <StateFeedback kind="error" title="Could not save settings.">
      <button type="button" className="ui-button ui-button-secondary" disabled={saving} onClick={() => { void retry(); }}>Retry</button>
    </StateFeedback>}
  </>;
}
